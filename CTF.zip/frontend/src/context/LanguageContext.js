import React, { createContext, useState, useContext } from 'react';
import enTranslations from '../translations/en';
import faTranslations from '../translations/fa';

const LanguageContext = createContext();

export const LanguageProvider = ({ children }) => {
  const [language, setLanguage] = useState('en');
  const translations = language === 'en' ? enTranslations : faTranslations;

  const toggleLanguage = () => {
    setLanguage(prevLang => prevLang === 'en' ? 'fa' : 'en');
  };

  return (
    <LanguageContext.Provider value={{ language, translations, toggleLanguage }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}; 