import React from 'react';
import { useLanguage } from '../context/LanguageContext';
import { Button, Box } from '@mui/material';

const LanguageSwitcher = () => {
  const { language, toggleLanguage, translations } = useLanguage();

  return (
    <Box sx={{ position: 'fixed', top: 16, right: 16, zIndex: 1000 }}>
      <Button
        variant="contained"
        onClick={toggleLanguage}
        sx={{
          backgroundColor: language === 'en' ? '#1976d2' : '#dc004e',
          '&:hover': {
            backgroundColor: language === 'en' ? '#1565c0' : '#c4004e',
          },
        }}
      >
        {translations.language.switch}
      </Button>
    </Box>
  );
};

export default LanguageSwitcher; 