import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Container, 
  Typography, 
  Card, 
  CardContent, 
  Grid,
  Box,
  Paper,
  List,
  ListItem,
  ListItemText,
  Divider,
  Stack,
  Avatar,
  Button
} from '@mui/material';
import endpoints from '../config/endpoints';
import { useLanguage } from '../context/LanguageContext';
import { useNavigate } from 'react-router-dom';

const HomePage = () => {
  const { translations } = useLanguage();
  const navigate = useNavigate();

  return (
    <Container maxWidth="md">
      <Box
        sx={{
          minHeight: '100vh',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'center',
          alignItems: 'center',
          textAlign: 'center',
          gap: 4,
        }}
      >
        <Typography variant="h2" component="h1" gutterBottom>
          {translations.home.title}
        </Typography>
        <Typography variant="h5" color="text.secondary" paragraph>
          {translations.home.description}
        </Typography>
        <Button
          variant="contained"
          size="large"
          onClick={() => navigate('/chat')}
        >
          {translations.home.startButton}
        </Button>
      </Box>
    </Container>
  );
};

export default HomePage; 