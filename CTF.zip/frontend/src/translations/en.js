export default {
  common: {
    welcome: 'Welcome to CTF Challenge',
    start: 'Start Challenge',
    submit: 'Submit',
    next: 'Next',
    previous: 'Previous',
    loading: 'Loading...',
    error: 'Error',
    success: 'Success',
  },
  home: {
    title: 'CTF Challenge Platform',
    description: 'Test your skills with our interactive CTF challenges',
    startButton: 'Get Started',
  },
  chat: {
    placeholder: 'Type your message here...',
    send: 'Send',
    thinking: 'Thinking...',
  },
  language: {
    english: 'English',
    persian: 'Persian',
    switch: 'Switch Language',
  },
}; 