export default {
  common: {
    welcome: 'به چالش CTF خوش آمدید',
    start: 'شروع چالش',
    submit: 'ارسال',
    next: 'بعدی',
    previous: 'قبلی',
    loading: 'در حال بارگذاری...',
    error: 'خطا',
    success: 'موفقیت',
  },
  home: {
    title: 'پلتفرم چالش CTF',
    description: 'مهارت‌های خود را با چالش‌های تعاملی CTF ما محک بزنید',
    startButton: 'شروع کنید',
  },
  chat: {
    placeholder: 'پیام خود را اینجا بنویسید...',
    send: 'ارسال',
    thinking: 'در حال فکر کردن...',
  },
  language: {
    english: 'انگلیسی',
    persian: 'فارسی',
    switch: 'تغییر زبان',
  },
}; 